package com.ust.productService.service;

import java.util.List;

import com.ust.productService.model.Product;


public interface ProductService {
	
	public List<Product> getAllProduct();
	public Product getProductById(Long productId);
	public Product updateProduct(Product product);

}
