package com.ust.productService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.productService.model.Product;
import com.ust.productService.service.ProductService;



@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;

	@GetMapping("/getAllProduct")
	public List<Product> getAllProduct(){
		return productService.getAllProduct(); 
	}
	
	@GetMapping("/{productId}")
	public Product getProductById(@PathVariable("productId") Long productId) {
		return productService.getProductById(productId);
	}
	
	@PutMapping("/update/{productId}")
	public void updateProductStock(@RequestBody Product product, @PathVariable("productId") Long productId) {
		Product existingProduct = productService.getProductById(productId);
		existingProduct.setQuantity(product.getQuantity());
		productService.updateProduct(existingProduct);
	}
}
