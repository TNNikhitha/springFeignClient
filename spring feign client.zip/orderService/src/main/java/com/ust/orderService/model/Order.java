package com.ust.orderService.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class Order {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long orderId;
	
	private Long productId;
	private Double quant;
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Double getQuant() {
		return quant;
	}
	public void setQuant(Double quant) {
		this.quant = quant;
	}
	public Order(Long orderId, Long productId, Double quant) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.quant = quant;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
