package com.ust.orderService.controller;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ust.orderService.model.Product;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@FeignClient(name="productService")
public interface ProductServiceClient {
	
	@GetMapping("/product/{productId}")
	@CircuitBreaker(name="productService",fallbackMethod="fallbackHello")
	Product getProductById(@PathVariable("productId") Long productId);
	
	default String fallbackHello(Throwable t) {
		return "Product Service is Down!";
	}
	

}
