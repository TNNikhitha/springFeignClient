package com.ust.orderService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.orderService.model.Order;
import com.ust.orderService.service.OrderService;

@RestController
@RequestMapping("/orderService")
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	
	 @PostMapping("/placeOrder/{productId}/{quant}")
	    public Order placeOrder(@PathVariable("productId") Long productId, @PathVariable("quant") Double quant) {
	        return orderService.placeOrder(productId, quant);
	    }

	    @GetMapping("/getOrder/{id}")
	    public Order getOrder(@PathVariable Long id) {
	        return orderService.getOrderById(id);
	    }
	
	

}
