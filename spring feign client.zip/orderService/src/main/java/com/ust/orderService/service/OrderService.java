package com.ust.orderService.service;

import com.ust.orderService.model.Order;


public interface OrderService {

	public Order placeOrder(Long productId, Double quant);
	public Order getOrderById(Long orderId);
}
