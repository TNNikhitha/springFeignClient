package com.ust.orderService.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.orderService.controller.ProductServiceClient;
import com.ust.orderService.model.Order;
import com.ust.orderService.model.Product;
import com.ust.orderService.repository.OrderRepo;


@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	private OrderRepo orderRepo;
	
	@Autowired
	private ProductServiceClient productServiceClient;

	@Override
	public Order placeOrder(Long productId, Double quant) {
		// TODO Auto-generated method stub
		Product product = productServiceClient.getProductById(productId);

        if (product.getQuantity() < quant) {
            throw new RuntimeException("Not enough stock available!");
        }
        

        // Place order
        Order order = new Order();
        order.setProductId(productId);
        order.setQuant(quant);

        return orderRepo.save(order);
	}

	@Override
	public Order getOrderById(Long orderId) {
		// TODO Auto-generated method stub
		Optional<Order> opt = orderRepo.findById(orderId);
		return opt.get();
	}

}
